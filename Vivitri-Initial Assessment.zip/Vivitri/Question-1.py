#1)Write a program to compute the frequency of the words from the input. The output should output after sorting the key alphanumerically.

sen=input("Enter a sentence: ").split()
res={}
for i in sorted(sen):
    res[i]=res.get(i,0)+1
for i in res.keys():
    print('{}:{}'.format(i,res[i]))
sen=input("Enter a sentence: ").split()
sen=input("Enter a sentence: ").split()
res={}
for i in sorted(sen):
    res[i]=res.get(i,0)+1
for i in res.keys():
    print('{}:{}'.format(i,res[i]))
