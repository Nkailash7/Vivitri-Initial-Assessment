#8)Pattern Printing
num=int(input("Enter a number: "))
for i in range(0,num):
    for j in range(1,num+1):
        if(j==num):
            print(j,end='')
        else:
            print('{}*'.format(j),end='')
    num=num-1
    print('\n',end='')