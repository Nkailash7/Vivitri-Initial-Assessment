#2)Write a program to check the validity of password input by users.
import re
pwd=input("Enter Password: ").split(',')
for i in pwd:
    if(len(i)>=6 and len(i)<=12):
        if re.search(r'[a-z]+',i) and re.search(r'[0-9]+',i) and re.search(r'[A-Z]+',i) and re.search(r'[$#@]+',i):
            print(i)