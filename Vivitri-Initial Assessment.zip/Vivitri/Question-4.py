#4)Finding words which are greater than given length k
sen=input("Enter a sentence: ").split()
res=[]
k=int(input("Enter K: "))
for i in sen:
    if len(i)>6:
        res.append(i)
print(','.join(res))