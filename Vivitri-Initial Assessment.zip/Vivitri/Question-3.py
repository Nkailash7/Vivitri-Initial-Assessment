#3)Write a program which takes 2 digits, X,Y as input and generates a 2-dimensional array. The element value in the i-th row and j-th column of the array should be i*j.
X, Y =input("Enter X,Y: ").split(",")
X = int(X)
Y = int(Y)
arr= [[x*y for y in range(Y)] for x in range(X)]
print(arr)