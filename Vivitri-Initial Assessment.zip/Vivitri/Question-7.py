#7)Pattern Printing
num=int(input("Enter a number: "))
for i in range(0,num):
    print(" "*i,end='')
    for j in range(num,i,-1):
        print(j,end=' ')
    print(" "*(i+i),end='')
    for k in range(i+1,num+1):
        print(k,end=' ')
    print("\n",end='')