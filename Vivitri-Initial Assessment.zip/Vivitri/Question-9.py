#9)Pattern Printing
num=int(input("Enter a number: "))
for i in range(1,num+1):
    for j in range(0,i):
        print('* ',end='')
    print('\n',end='')
print('\n',end='')
for i in range(num,0,-1):
    for j in range(0,i):
        print('* ',end='')
    print('\n',end='')
